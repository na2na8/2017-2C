#include <stdio.h>
#include <math.h>

double doublesqrt(int k)
{
	double x = sqrt(sqrt(k));

	return x;
}

int main(int argc, char const *argv[])
{
	printf("%-10s %-10s\n", "Integer k", "doubleSQRT" );
	printf("%10d %10f\n", 10, doublesqrt(10));
	printf("%10d %10f\n", 35, doublesqrt(35));
	return 0;
}