#include <stdio.h>

int is_prime(int n)
{
	int k = 2;
	for(; k<n ; k++){
		if(n % k == 0)
			return 0;
		else
			continue;
	}
	return 1;
}

int main(int argc, char const *argv[])
{
	printf("%d\n", is_prime(7));
	printf("%d\n", is_prime(39));
	printf("%d\n", is_prime(196));
	return 0;
}