#include <stdio.h>

int main(int argc, char const *argv[])
{
	int n;
	int sum = 0;
	printf("Input integer : ");
	scanf("%d", &n);
	int i = n;
	if(n>0){
		for(;i<=2*n; i++){
			sum += i;
		}
		printf("%d\n", sum);
	}
	if(n<0){
		for(;2*n<=i; i--){
			sum += i;
		}
		printf("%d\n", sum);
	}
	return 0;
}
