#include <stdio.h>

int main(int argc, char const *argv[])
{
	for(;;){
		printf("TRUE FOREVER");
	}
	return 0;
}