#include <stdio.h>

int min(x,y,z){
	 int save, new;
	 save = (x < y) ? x : y;
	 new = (save < z) ? save : z;
	 printf("%d\n", new);
	 return new;
}

int max(x,y,z,w){
	int save, new;
	save = (x > y) ? x : y;
	new = (save > z) ? save : z;
	save = (new > w) ? new : w;
	printf("%d\n", save);
	return save;
}

int main(int argc, char const *argv[])
{
	int x, y, z, w;
	printf("Input four integers : ");
	scanf("%d %d %d %d",&x,&y,&z,&w);
	min(x,y,z);
	max(x,y,z,w);
	return 0;
}
