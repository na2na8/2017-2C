#include <stdio.h>

int main(int argc, char const *argv[])
{
	char c = -1;
	signed char s = -1;
	unsigned char u = -1;

	printf("c = %d s = %d u = %d\n", c, s, u);
	printf("unsigned c = %d", (unsigned char)c);
	return 0;
}