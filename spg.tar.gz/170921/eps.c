#include <stdio.h>

int main(void){
	double eps = 1E -37;
	if (1.0 < 1.0 + eps)
		printf("%s\n", "true");
	return 0;
}