#include <stdio.h>

int main(int argc, char const *argv[])
{
	int n;
	int sum = 0;
	printf("Input integer : ");
	scanf("%d", &n);
	int i = n;
	if(n>0){
		while(i<=2*n){
			sum += i;
			i++;
		}
		printf("%d\n", sum);
	}
	else if(n<0){
		while(i>=2*n){
			sum += i;
			i--;
		}
		printf("%d\n", sum);
	}
	return 0;
}