#include <stdio.h>

int main(void){
	int a, b=2000000000, c=2000000000;

	a = b + c;
	printf("%d\n",a);
	return 0;
}