#include <stdio.h>

int gcd(int A, int B)
{	
	int a, b, r;
	if (A < B) {
		a = B;
		b = A;
	}
	else {
		a = A;
		b = B;
	}
	//--------------------------

	r = a % b;

	while (r != 0) {
		a = b;
		b = r;
		r = a % b;	
	}
	return b;
}

int main(void)
{
	printf("gcd(10, 15) = %d\n", gcd(10, 15));
	printf("gcd(125, 13) = %d\n", gcd(125, 13));
	printf("gcd(625, 225) = %d\n", gcd(625, 225));
	printf("gcd(6840, 324) = %d\n", gcd(6840, 324));
}