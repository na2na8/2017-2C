#include <stdio.h>

#define GREETIGS(a, b, c)\
	printf(#a "," #b ", and " #c " : Hello!\n")
#define WORNG_GREETINGS(a, b, c)\
	printf("a, b, c : Hello!\n")

#define EXEC(x) func_##x()

void func_A()
{
	printf("This is func_A()\n");
}

void func_B()
{
	printf("This is func_B()\n");
}

int main(int argc, char const *argv[])
{
	GREETIGS(Alice, Bob, Carole);
	WORNG_GREETINGS(Alice, Bob, Carole);

	EXEC(A);
	EXEC(B);
	
	return 0;
}