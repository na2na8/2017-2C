#include <stdio.h>
#include <stdlib.h>

#define N 3

void fct1(int k);
void fct2(void);
void wrt_info(char*);