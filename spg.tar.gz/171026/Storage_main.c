#include <stdio.h>

int a = 1, b = 2;
int c = 3;

int extern_function(void);
int static_function(void);

int main(int argc, char const *argv[])
{
	printf("%3d\n", extern_function() );
	printf("%3d%3d%3d\n", a, b, c);
	static_function();
	static_function();
	return 0;
}