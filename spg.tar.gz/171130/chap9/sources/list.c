#include <stdio.h>
#include <stdlib.h>
#include "../headers/node.h"

//Define 'list' using typedef and struct.
typedef struct list{
	int size;
	node* head;
}list;

list* init_list();
void appendTo(list* list, node* newnode);
void delAt(list* list, int n);
void print_list(list* list);

list* init_list(){
	list* new_list = (list*)malloc(sizeof(list));
	new_list->size = 0;
	new_list->head = NULL;
	return new_list;
}

void appendTo(list* list, node* newnode){
	list->size += 1;
	node* this = list->head;
	
	if(this == NULL){
		list->head = newnode;
		return ;
	}
	
	while(1){
		if (this->next == NULL){
			this->next = newnode;
			break;
		}
		this = this->next;
	}
}


void delAt(list* list, int n){
	printf("Delete %d index of linked list\n", n);
	printf("---------------------------------\n");
	if (list->size == 0){
		printf("There is no element.\n");
		return;
	}
	
	if ( n < 0 && n > list->size ) {
		printf("delAt() : out of index ( n = %d )\n\n", n);
		return;
	}

	node* prev = list->head;
	node* this = list->head;
	int i;
	int found = 0;
	for (i = 0; i < list->size; i++){
		if (this-> val == n) {
			found = 1;
			break;
		}
		prev = this;
		this = this->next;
	}

	if (found)
	{
		list->size = list->size - 1;
		if (i==0){
			list->head = this->next;
			free(this);
		} else {
			prev->next = this->next;
			free(this);
		}
	}
}

void print_list(list* list){
	printf("list size = %d\n", list->size);
	node* y = list->head;
	for(int i = 0; i<list->size ; i++){
		printf("[%d] ", y->val);
		y = y->next;
	}
	printf("\n\n");
}

int main(int argc, char const *argv[]) {
	list* linked = init_list();
	int i;
	for(i = 1; i < 6 ; i++){
		appendTo(linked, newnode(i));
	}
	print_list(linked);
	delAt(linked, -1);
	delAt(linked, 5);
	print_list(linked);
	delAt(linked, 3);
	print_list(linked);
	return 0;
}
