#include <stdio.h>
#include <stdlib.h>
#include "../headers/node.h"

//Define 'stack' using typedef and struct. stack has top, size
typedef struct stack {
	node* top;
	int size;
}stack;

stack* init_stack();
void push(stack* stack, node* newnode);
int pop(stack* stack);
int top(stack* stack);
void print_stack(stack* stack);

stack* init_stack(){
	stack* new_stack = (stack*)malloc(sizeof(stack));
	new_stack->size = 0;
	new_stack->top = NULL;
	return new_stack;
}

void push(stack* stack, node* newnode){
	stack->size += 1;

	if(stack->top == NULL){
		stack->top = newnode;
		return ;	
	}
	
	//stack= stack->top
	newnode->next = stack->top;
	stack->top = newnode;

}

int pop(stack* stack){

	if(stack->size == 0){
		printf("pop() : stack is empty.\n");
		return 0;
	}

	if(stack->size == 1) {
		node* this = stack->top;
		stack->top = NULL;
		free(this);
	} else {
		node* this = stack->top;
		stack->top = this->next;
		free(this);
	}
	stack->size -= 1;
	return 1;
}

int top(stack* stack){
	if(stack->size != 0) {
		node* this = stack->top;
		return this->val;
	} else {
		printf("top() : stack is empty.\n");
		return 0;
	}
}

void print_stack(stack* stack){
	node* x = stack->top;
	printf(" Top\n");
	for(int i = 0; i<stack->size ; i++){
		printf(" [%d]\n", x->val);
		x = x->next;
	}

}

int main(int argc, char const *argv[])
{
	int i;
	stack* s = init_stack();
	push(s, newnode(1));
	printf("top : %d\n", top(s));
	pop(s);
	pop(s);
	for(i = 2; i<6 ; i++){
		push(s, newnode(i));
	}
	pop(s);
	print_stack(s);
	for(i = 0; i < 3; i++) pop(s);
	top(s);

	return 0;
}