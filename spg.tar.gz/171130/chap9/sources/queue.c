#include <stdio.h>
#include <stdlib.h>
#include "../headers/node.h"

//Define 'queue' using typedef and struct. queue has front, rear, and size
typedef struct queue{
	node* front;
	node* rear;
	int size;
}queue;

queue* init_queue();
void enqueue(queue* queue, node* newnode);
void dequeue(queue* queue);
int front(queue* queue);
void print_queue(queue* queue);

queue* init_queue(){
	queue* new_queue = (queue*)malloc(sizeof(queue));
	new_queue->size = 0;
	new_queue->front = NULL;
	new_queue->rear = NULL;
	return new_queue;
}

void enqueue(queue* queue, node* newnode){

	if(queue->size == 0){
		queue->rear = newnode;
		queue->front = newnode;
	} else {
		queue->rear->next = newnode;
		queue->rear = newnode;
	}

	queue->size += 1;
	return ;
}

void dequeue(queue* queue){

	if(queue->size == 0){
		printf("dequeue() : queue is empty\n");
		return ;
	}

	node* this = queue->front;

	if(queue->size == 1) {
		queue->front = NULL;
		queue->rear = NULL;
	}
	else {
		node* this = queue->front;
		queue->front = this->next;
	}
	free(this);

	queue->size -= 1;
	
}

int front(queue* queue){
	if(queue->size != 0) {
		return queue->front->val;
	} else {
		printf("front() : queue is empty\n");
		return 0;
	}
}

void print_queue(queue* queue){
	node* x = queue->front;
	printf("Q:");
	for(int i = 0; i<queue->size ; i++){
		printf(" [%d]", x->val);
		x = x->next;
	}
	printf("\n");

}

int main(int argc, char const *argv[]){
	int i;
	queue* q = init_queue();
	enqueue(q, newnode(1));
	printf("front : %d\n", front(q));
	dequeue(q);
	dequeue(q);
	for(i = 2; i<6 ; i++){
		enqueue(q, newnode(i));
	}
	dequeue(q);
	print_queue(q);
	for(i = 0; i<3; i++) dequeue(q);
	front(q);
	return 0;
}