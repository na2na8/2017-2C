#include <stdio.h>

//structure
struct card{
	int pips;
	char suit;
};

//structure using typedef
typedef struct {
	double re;
	double im;
} complex;

//Nested structure
struct dept {
	char name[25];
	int no;
};

typedef struct {
	char name[25];
	int     employee_id;
	struct dept    department;
	double salary;
}employee_data;

int main(int argc, char const *argv[])
{
	struct card cards[4] = {{1, '0'}, {2, '5'}, {3, 'C'}, {4, 'H'}};

	employee_data a = {
		"john",
		3,
		{"Engineering, 3"},
		1000
	};

	printf("Name : %s\nid    : %d\nDept : %s\nDept_no : %d\nSalary : %5.1f$\n", a.name, a.employee_id, a.department.no, a.salary );
	return 0;
}