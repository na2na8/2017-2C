#include <stdio.h>

int main(int argc, char const *argv[])
{
	char *s = "hello";
	char *p = s;
	printf("%c\t%c\n", p , s);
	return 0;
}