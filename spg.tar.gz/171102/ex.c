#include <stdio.h>

int main(int argc, char const *argv[])
{
	double a[3] = { 1, 2, 3};
	double *b;
	b = &a[0];

	printf("%p\n", a);
	printf("%p\n", b);
	return 0;
}