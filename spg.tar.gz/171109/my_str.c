#include <stdio.h>
#include <stdlib.h>


size_t strlen(const char *s)
{
	size_t n;
	for (n = 0; *s != '\0'; ++s)
		++n;
	return n;
}

char *strcpy(char *s1, register const char *s2)
{
	register char *p = s1;
	while (*p++ = *s2++)
		;
	return s1;
}

char *my_strcat(char *s1, const char *s2)
{
	char *temp = s1;
	int length = strlen(s1);
	for(int i =0; i< strlen(s2); i++){
		*(temp+length+i) = *(s2+i);
	}
	
	return s1;
}

int my_strcmp(const char *s1, const char *s2)
{
	int c;

	for(int i = 0; i<strlen(s1); i++){
		c = s1[i]-s2[i];
		if(c != 0){
			break;
		}
	}

	return c;
}

int main(int argc, char const *argv[])
{
	char *str1 = "STARBUCKS";
	char str2[10] = "STAR";
	char *str3 = "BUCKS";
	my_strcat(str2, str3);
	if (my_strcmp(str1, str2) == 0)
		printf("Nailed it!\n");
	else
		printf("my_strcmp(str1, str2): %d\n", my_strcmp(str1, str2) );

	return 0;
}
