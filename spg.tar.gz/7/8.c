#include <stdio.h>
#include <limits.h>

void bit_print(int a)
{
	int i;
	int n = sizeof(int) * CHAR_BIT;
	int mask = 1 << (n-1);

	for(i = 1; i<= n; ++i){
		putchar(((a & mask) == 0) ? '0' : '1');
		a <<= 1;
		if (i % CHAR_BIT == 0 && i < n)
			putchar(' ');
	}
	putchar('\n');
}

int main(int argc, char const *argv[])
{
	printf("0 : ");
	bit_print(0);
	printf("\n");
	printf("1 : ");
	bit_print(1);
	printf("\n");
	printf("15 : ");
	bit_print(15);
	printf("\n");
	return 0;
}