#include <stdio.h>

int main(void){
	printf("Why is 21 + 31 equal to %d?\n", 2l+3l);
	return 0;
}