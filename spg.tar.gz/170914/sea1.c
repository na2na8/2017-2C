#include <stdio.h>
int main(void){
	printf("from sea to ");
	printf("Shining C ");
	printf("\n");
	return 0;
}

