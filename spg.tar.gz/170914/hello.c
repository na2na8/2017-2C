#include <stdio.h>
int main(void){
	printf("HelloWorld\n");
	return 0;
}

