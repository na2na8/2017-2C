#include <stdio.h>
int main(void){
	printf("from c \n");
	printf("to Shining \nC\n");
	return 0;
}

