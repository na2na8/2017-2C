#include <stdio.h>
int main(void){

	int hippo;
	float bolt, phelps;

	int earth_hippo = 50;
	bolt = 44.7;
	float n1 = earth_hippo - bolt;

	int water_hippo = 9;
	phelps = 9.6;
	float n2 = phelps - water_hippo;

	printf("hippo - bolt = %f", n1);
	printf("\nphelps - hippo = %f", n2);
	printf("\n");
	
	return 0;
}
