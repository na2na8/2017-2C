#include <stdio.h>
#include <string.h>

int find(char s[]){
	int num = strlen(s);
	int middle = num/2;
	if (num == 1 || 0){
		return 1;
	}
	if (num%2 == 0){
		for(int i = 0; i<=middle; i++){
			if (s[i] == s[num-i-1])
				continue;
			else
				return 0;
		}
		return 1;
	}
	else{
		for(int i = 0; i<middle; i++){
			if (s[i] == s[num-i-1])
				continue;
			else
				return 0;
		}
		return 1;
	}
}

int main(int argc, char const *argv[])
{
	printf("\"ABCBA\"%d\n", find("ABCBA"));
	printf("\"123343321\"%d\n", find("123343321"));
	printf("\"otto\"%d\n", find("otto"));
	printf("\"i am ma i\"%d\n", find("i am ma i"));
	printf("\"C\"%d\n", find("C"));
	return 0;
}