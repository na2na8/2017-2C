#include <stdio.h>

#define N 5 /* N is the max degree */

int eval_1(int p[], int x, int n)/* n is max degree */
{
	int sum = 0;
	for (int i = 0; i <= n ; i++){
		int sup_x = 1;
		for (int j = 0; j<i ; j++){
			sup_x *= x;
		}
		sum += p[i]*sup_x;
	}
	return sum;
}

int eval_2(int p[], int x, int n)
{
	int sum = 0;
	for(int i = n; i>=0 ; i--){
		sum *= x;
		sum += p[i];
	}
	return sum;
}

int main(int argc, char const *argv[])
{	
	int p[N +1] = {1, 2, 3, 4, 5, 6};
	printf("%d %d\n", p[0], p[5]);
	printf("eval_1(2) : %d\n", eval_1(p, 2, 5));
	printf("eval_2(2) : %d\n", eval_2(p, 2, 5));
	return 0;
} 	