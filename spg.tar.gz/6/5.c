#include <stdio.h>

int main(int argc, char const *argv[])
{
	char a, b, c, *p, *q, *r;
	printf("%p %p %p %p %p %p\n", a, b, c, p, q, r);
	return 0;
}