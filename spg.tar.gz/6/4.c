#include <stdio.h>

int main(int argc, char const *argv[])
{
	int i = 3, j = 4;
	int *p, *q;
	p = &i;
	q = &j;
	printf("p = &i : %p\n", p);
	printf("p = &*&i : %p\n", &*p);
	printf("i = (int)p : %p\n", i = (int)p);
	printf("q = &p : %d\n", q = &p);
	printf("*q = &j : %p\n", *q = &i);
	printf("i = *&*&j : %d\n", i = *&*&j);
	printf("i = *p++ + *q : %d\n", i = *p++ + *q);
	return 0;
}