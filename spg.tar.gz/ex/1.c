#include <stdio.h>

int main(int argc, char const *argv[])
{
	double x = 7e+33;
	double y = 0.001;

	printf("%f\n", x);
	printf("%f\n", x+y);


	return 0;
}