#include <stdio.h>

int main(int argc, char const *argv[])
{
	float ex, g = 1, eps ;
	do
	{
		g = g/2;
		ex = g*0.98 -1;
		ex = ex-1;

		printf("g = %15.8e    ex = %15.8e\n", g, ex);

		if(ex > 0) eps = ex;
	}

	while(ex > 0);

	printf("\n Machine epsilon = %16.8e\n\n", eps);
	return 0;
}