#include <stdio.h>

int main(int argc, char const *argv[])
{
	double eps = 1e-15; //from 1e-37   ,, 15
	printf("%d\n", 1.0<1.0 + eps );
	printf("%f\n", 1.0+eps);

	if(1.0 < 1.0 + eps){
		printf("Yes\n");
	}

	printf("%d\n",sizeof(double));
	return 0;
}