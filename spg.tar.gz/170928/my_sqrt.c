#include <stdio.h>
#include <math.h>
double my_sqrt(double number)
{
	double sqrt;
	double xn , x0 = 1;
	int count = 1;
	for (;count <= 1000; count++){
		xn = (x0 + number/x0)/2;
		x0 = xn;
	}
	sqrt = xn;
	return sqrt;
}

int main(int argc, char const *argv[])
{
	double x;
	printf("Insert non-negative number x : ");
	scanf("%lf", &x);
	printf("\nsqrt(x) = %10lf, sqrt(x)^2 = %.0lf\n
		", my_sqrt(x), my_sqrt(x)*my_sqrt(x));
	return 0;
}