#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[])
{
	char *p1 = "abc", *p2 = "pacific sea";

	printf("%s\t%s\t%s\n", p1, p2, strcat(p1,p2));
	return 0;
}