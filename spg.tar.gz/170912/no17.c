#include <stdio.h>

int main(void){
	int a, b, c;
	a = (a=1) + (b=((b=2) + (c=((c=3) + 7))));
	printf("%d %d %d", a, b, c);
	return 0;
}