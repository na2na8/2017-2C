#include <stdio.h>

int main(void){
	int a, b, sum;

	printf("Input two Integers: ");
	scanf("%d%d", &a, &b); //& : address
	sum = a + b;
	printf("%d + %d = %d\n", a, b, sum );

	int i = 0;
	int j = 0;
	printf("%d %d", i++, ++j);
	printf("\n");
	return 0;
}