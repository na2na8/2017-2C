#include <stdio.h>

int main(void){
	int power = 2048;
	for(;(power/2)>0;power /= 2)
		printf("%-6d", power);
}