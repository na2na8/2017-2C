#include <stdio.h>

#define MAX(x, y, z)\
	(((x)>(y))? (x) : (y)) > (z) ? (((x)>(y))? (x) : (y)) : (z)

#define max(x, y, z)\
	((x>y)? x : y) > (z) ? ((x>y)? x : y) : z


int main(int argc, char const *argv[])
{
	printf("%d\n", MAX(3+6, 3, 8));
	printf("%d\n", max(3+6, 3, 8) );
	return 0;
}