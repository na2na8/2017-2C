#if TRUE
	#include <stdio.h>
	#include ".../spg/8/a_b_c.h"
	A_B_C
#endif