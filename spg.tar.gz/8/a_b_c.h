#define TRUE 1
int main(int argc, char const *argv[])
{	
#define A_B_C
	printf("A Big Cheery\"hello\"!\n");
	return 0;
}